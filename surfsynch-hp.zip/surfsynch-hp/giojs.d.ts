declare module "giojs";
